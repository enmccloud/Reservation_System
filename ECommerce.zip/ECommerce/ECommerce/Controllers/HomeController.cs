﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using ECommerce.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Http;

namespace ECommerce.Controllers
{
	public class HomeController : Controller
	{
		private readonly ILogger<HomeController> _logger;
		private readonly AppDbContext _dbContext;
		private readonly UserManager<IdentityUser> userManager;
		private readonly RoleManager<IdentityRole> roleManager;
		public HomeController(ILogger<HomeController> logger, RoleManager<IdentityRole> roleManager, UserManager<IdentityUser> userManager,AppDbContext dbContext)
		{
			_logger = logger;
			_dbContext = dbContext;
			this.userManager = userManager;
			this.roleManager = roleManager;
		}
		
		public IActionResult Index()
		{
			return View();
		}

		public IActionResult Profile()
		{
			return View();
		}
		
		[Authorize(Roles ="Admin")]
		public IActionResult DeleteProfile()
		{
			var profiles = _dbContext.Users.Select(u =>new UserProfile
			{
				Id=u.Id,
				Email=u.Email,
				UserName=u.UserName,
				UserRole= string.Join(",", userManager.GetRolesAsync(u).GetAwaiter().GetResult())
			})?.ToList();

			return View(profiles);
		}

		[Authorize(Roles = "Admin")]
		[HttpPost]
		public async Task<IActionResult> DeleteProfile(IFormCollection formData)
		{
			if (formData.ContainsKey("id"))
			{
				var selectedId = formData["id"].ToString();
				var selectedRole = formData["role"].ToString();
				var selectedUser = _dbContext.Users.FirstOrDefault(u => u.Id == selectedId);
				if (!string.Equals(selectedUser.UserName, User.Identity.Name))
				{
					await userManager.RemoveFromRolesAsync(selectedUser, selectedRole.Split(","));
					await userManager.DeleteAsync(selectedUser);
				}				
			}
			var profiles = _dbContext.Users.Select(u => new UserProfile
			{
				Id = u.Id,
				Email = u.Email,
				UserName = u.UserName
			})?.ToList();
			return View(profiles);
		}

		[ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
		public IActionResult Error()
		{
			return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
		}
	}
}
